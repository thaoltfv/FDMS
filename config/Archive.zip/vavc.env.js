'use strict'
module.exports = {
    
  API_URL: '"https://vavc-api.fastvalue.vn"',
  PUSHER_KEY: '"1290d781094bb6322e89"',
  
  firebaseConfig:`{
    apiKey: "AIzaSyA7J0t0X_Shu1tB_dZCbaXP6BLkkn8_O2k",
    authDomain: "fv-vavc.firebaseapp.com",
    projectId: "fv-vavc",
    storageBucket: "fv-vavc.appspot.com",
    messagingSenderId: "257897107616",
    appId: "1:257897107616:web:f28515e0e618a0a559f9c5"
  }`
}